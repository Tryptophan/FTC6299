## FTC 6299 Source Code
[Viperbots](http://www.viperbots.org/) | [FTC 6299](http://www.viperbotsboosters.org/teams/6299-quadx/) | [GitHub](https://github.com/Tryptophan/FTC6299)

### Developers
* Joshua Johnson
* Linnea May
* Jacob Greenway

### Documentation

#### Motors

``` setMotors(int fl, int bl, int fr, int br) ```
* Sets the speed of all four motors

``` setLift(int speed) ```
* Sets the lift motors to a specified speed

``` stopMotors() ```
* Stops all motors, including the drive and lift motors

``` lift(float t, int speed) ```
* Moves the lift up or down at a specified speed for a specified amount of time

#### Encoders

``` moveTo(int deg, int speed) ```
* Moves forward or backward specified amount of degrees at the specified speed

``` pickUp(int deg, int speed) ```
* Moves forward or back a specified degrees and spins the foam wheels

#### Gyro Sensor

``` turn(int deg, int speed) ```
* Turns left or right using the gyroscope at a specified speed

#### Infared Sensor

``` irScan(int val, int speed, int dir) ```
* Moves specified direction at a specified speed until it hits an ir value

``` leftOrRight() ```
* Returns a -1 or 1 depending on which side of the baskets the ir  beacon is on

#### Ultrasonic Sensor

``` waitForWall(int dis, int speed) ```
* Moves forward a specified speed until the ultrasonic sensor is the specified distance away from the object in cm

#### Motor and Sensor Setup

##### Drive Train
* Port 1, Controller 1, Motor 1: motorFL
* Port 1, Controller 1, Motor 2: motorBL
* Port 1, Controller 2, Motor 1: motorFR
* Port 1, Controller 2, Motor 2: motorBR

##### Manipulation Motors
* Port 1, Controller 3, Motor 1: grabMotor
* Port 1, Controller 3, Motor 2: flagMotor

##### Lift Motors
* Port 1, Controller 4, Motor 1: liftMotorL
* Port 1, Controller 4, Motor 2: liftMotorR

##### Bucket Servos
* Port 2, Controller 1, Servo 1: servoL
* Port 2, Controller 1, Servo 2: servoR

##### Ratchet Servos
* Port 2, Controller 1, Servo 3: ratchetL
* Port 2, Controller 1, Servo 4: ratchetR

##### Sensors
* Port 3: Hitchnic Gyro (HTGR)
* Port 4: Hitechnic Sensor Multiplexer (SMUX)
  * Port 4, SMUX Port 1: Hitechnic Infared Sensor (HTIRS1)
  * Port 4, SMUX Port 3: Lego Ultrasonic Sensor (LGUS)
  * Port 4, SMUX Port 4: Hitechnic Infared Sensor (HTIRS2)

#### Other Notes
* Make sure your RobotC version is up to date (3.62)
* Swerve drive was thrown out for now, when turning we use a magnetic compass and only move forawrd and back with the accelerometer
* Sensor naming: HT (HiTechnic) followed by an abbreviation of the sensor AC, MC, IR (Accelerometer, Magnetic Compass, Infared)
* View the license for concerns on using the code for yourself
